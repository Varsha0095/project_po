# Instructions to access the zip folder
1. Download the zip folder.
2. Extract all the files.
3. Open the code in VS Code and run the command - 
   
   ```npm install node_modules```

4. Then , run the command 

    ```npm start```

5. You will be redirected to localhost:3000

# List of Dependencies - 
Following dependencies are required for this project.

1. react-dom
2. react-router-dom
3. leaflet
4. react-leaflet
5. bootstrap
6. react-bootstrap


